"""Beta SDK runtime helpers."""
