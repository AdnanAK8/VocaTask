"""Core configuration and settings."""
