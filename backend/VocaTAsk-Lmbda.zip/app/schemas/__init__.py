"""Data schemas and models."""
